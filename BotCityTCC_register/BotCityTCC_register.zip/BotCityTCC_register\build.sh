#!/bin/bash

zip -r "BotCityTCC_register.zip" * -x "BotCityTCC_register.zip"