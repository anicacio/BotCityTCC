#!/bin/bash

zip -r "BotCityTCC.zip" * -x "BotCityTCC.zip"